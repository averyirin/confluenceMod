<?php

/**
 * Description of Repository
 *
 * @author AlexMc
 */
abstract class Repository {
    //put your code here
}
