<?php

?>
<p class="error" ng-message="required"><?php echo elgg_echo('projects:msg:required'); ?></p>
<p class="error" ng-message="email"><?php echo elgg_echo('projects:msg:email'); ?></p>
<p class="error" ng-message="minlength"><?php echo elgg_echo('projects:msg:short'); ?></p>
<p class="error" ng-message="maxlength"><?php echo elgg_echo('projects:msg:long'); ?></p>